package com.example.lotto;


import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;


import java.util.HashMap;
import java.util.Map;

public class ThirdActivity extends AppCompatActivity {
    TextView tv, txtResult;
    Button bt, btn;
    EditText et;
    String no1, no2, no3, no4, no5, no6, bonus, drwNo;
    JsonObject jsonObject;
    RequestQueue requestQueue;
    DBHelper dbHelper;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("인사말").setMessage("경성대학교\n소프트웨어학과\n2017848055\n송승준");
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.third);
        setTitle("당첨 번호 조회");
        tv = findViewById(R.id.tv);
        et = findViewById(R.id.et);
        bt = findViewById(R.id.bt);
        btn = findViewById(R.id.btn);
        txtResult = findViewById(R.id.txtResult);
        dbHelper = new DBHelper(ThirdActivity.this, 1);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestLotto();
            }
        });
        if(requestQueue == null){
            requestQueue = Volley.newRequestQueue(getApplicationContext());
        }
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtResult.setText(dbHelper.getResult());
            }
        });
    }

    public void requestLotto(){
        drwNo = et.getText().toString();
        if(drwNo.equals("")){
            Toast.makeText(this, "회차 번호를 입력하세요", Toast.LENGTH_SHORT).show();
            return;
        }

        String url = "https://www.dhlottery.co.kr/common.do?method=getLottoNumber&drwNo=" + drwNo;
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                jsonObject = (JsonObject) JsonParser.parseString(response);
                no1 = "당첨번호 1 - " + jsonObject.get("drwtNo1");
                no2 = "당첨번호 2 - " + jsonObject.get("drwtNo2");
                no3 = "당첨번호 3 - " + jsonObject.get("drwtNo3");
                no4 = "당첨번호 4 - " + jsonObject.get("drwtNo4");
                no5 = "당첨번호 5 - " + jsonObject.get("drwtNo5");
                no6 = "당첨번호 6 - " + jsonObject.get("drwtNo6");
                bonus = "보너스 - " + jsonObject.get("bnusNo");
                tv.setText(drwNo + "회차 당첨번호\n\n" + no1 + "\n" + no2 + "\n" + no3 + "\n" + no4 + "\n" + no5 + "\n" + no6 + "\n" + bonus);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>(); return params;
            }
        };
        request.setShouldCache(false);
        requestQueue.add(request);
    }
}
