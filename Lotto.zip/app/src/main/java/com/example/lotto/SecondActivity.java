package com.example.lotto;

import android.app.AlertDialog;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashSet;
import java.util.Set;

public class SecondActivity extends AppCompatActivity implements View.OnClickListener {
    // 디자인 변수 선언
    Button btnSave, btnSelect, btnReset;
    EditText edtRound, edtNum1, edtNum2, edtNum3, edtNum4, edtNum5, edtNum6;

    TextView viewResult;

    // DBHelper
    DBHelper dbHelper;

    int idNumbers[] = {R.id.num1, R.id.num2, R.id.num3, R.id.num4, R.id.num5, R.id.num6};
    int lottoNums[] = new int[6];

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("인사말").setMessage("경성대학교\n소프트웨어학과\n2017848055\n송승준");
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 디자인 매핑
        setContentView(R.layout.second);
        setTitle("로또 번호 저장");

        // Control 매핑
        btnSave = (Button) findViewById(R.id.btnSave);
        btnSelect = (Button) findViewById(R.id.btnSelect);
        btnReset = (Button) findViewById(R.id.btnReset);
        edtRound = (EditText) findViewById(R.id.edtRound);
        edtNum1 = (EditText) findViewById(R.id.edtNum1);
        edtNum2 = (EditText) findViewById(R.id.edtNum2);
        edtNum3 = (EditText) findViewById(R.id.edtNum3);
        edtNum4 = (EditText) findViewById(R.id.edtNum4);
        edtNum5 = (EditText) findViewById(R.id.edtNum5);
        edtNum6 = (EditText) findViewById(R.id.edtNum6);

        viewResult = (TextView) findViewById(R.id.txtResult);

        // 버튼 클릭 이벤트 정의
        btnSave.setOnClickListener(this);
        btnSelect.setOnClickListener(this);
        btnReset.setOnClickListener(this);
        dbHelper = new DBHelper(SecondActivity.this, 1);

        Button makeNumber = (Button) findViewById(R.id.btn);
        makeNumber.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v){
                Toast.makeText(getApplicationContext(), "Lotto 번호를 생성하였습니다.", Toast.LENGTH_SHORT).show();
                makeLottoNumbers();
                for (int i = 0; i < idNumbers.length; i++) {
                    TextView lottoNumber = (TextView) findViewById(idNumbers[i]);
                    String str = "" + lottoNums[i];
                    lottoNumber.setText(str);
                }
            }
        });
    }

    private void makeLottoNumbers() {
        Set<Integer> s = new HashSet<>();
        int n;
        for(int i = 0; i < 6;) {
            n = (int) (Math.random() * 45 + 1);
            if(s.add(n)) {
                lottoNums[i++] = n;
            }
        }
        s.clear();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSave:
                EditText[] edtarray = new EditText[]{edtRound, edtNum1, edtNum2, edtNum3, edtNum4, edtNum5, edtNum6};
                int correct = 6;

                if (edtarray[0].getText().toString().length() == 0) { // 회차 정보 미입력시
                    Toast.makeText(getApplicationContext(), "회차 정보를 입력해 주세요", Toast.LENGTH_SHORT).show();
                    break;
                }
                if (edtarray[1].getText().toString().length() == 0 || edtarray[2].getText().toString().length() == 0 || // 로또 번호 미입력시
                        edtarray[3].getText().toString().length() == 0 || edtarray[4].getText().toString().length() == 0 ||
                        edtarray[5].getText().toString().length() == 0 || edtarray[6].getText().toString().length() == 0) {
                    Toast.makeText(getApplicationContext(), "로또 번호를 입력해 주세요", Toast.LENGTH_SHORT).show();
                    break;
                }
                for (int i = 1; i < 7; i++) // 로또 번호가 1 미만 또는 45 초과일시
                {
                    if (Integer.parseInt(edtarray[i].getText().toString()) > 45 || Integer.parseInt(edtarray[i].getText().toString()) < 1) {
                        Toast.makeText(getApplicationContext(), "올바른 로또 번호를 입력해 주세요", Toast.LENGTH_SHORT).show();
                        break;
                    } else correct--;
                }

                if (correct == 0)
                {
                    dbHelper.insert(
                            Integer.parseInt(edtRound.getText().toString()),
                            Integer.parseInt(edtNum1.getText().toString()),
                            Integer.parseInt(edtNum2.getText().toString()),
                            Integer.parseInt(edtNum3.getText().toString()),
                            Integer.parseInt(edtNum4.getText().toString()),
                            Integer.parseInt(edtNum5.getText().toString()),
                            Integer.parseInt(edtNum6.getText().toString())
                    );
                    Toast.makeText(getApplicationContext(), "저장이 완료 되었습니다", Toast.LENGTH_SHORT).show();
                    break;
                }
            case R.id.btnSelect:
                viewResult.setText(dbHelper.getResult());
                break;
            case R.id.btnReset:
                SQLiteDatabase sqlDB = dbHelper.getWritableDatabase();
                dbHelper.onUpgrade(sqlDB, 1, 2);
                sqlDB.close();
                break;
        }
    }
}