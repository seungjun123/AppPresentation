package com.example.lotto;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    static final String DATABASE_NAME = "test3.db";

    // DBHelper 생성자
    public DBHelper(Context context, int version) {
        super(context, DATABASE_NAME, null, version);
    }

    // Lotto Table 생성
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Lotto(NumRound INT, Num1 INT, Num2 INT, Num3 INT, Num4 INT, Num5 INT, Num6 INT)");
    }

    // Lotto Table Upgrade
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Lotto");
        onCreate(db);
    }

    // Lotto Table 데이터 입력
    public void insert(int numround, int num1, int num2, int num3, int num4, int num5, int num6) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO Lotto VALUES(" + numround + ", " + num1 + ", " + num2 + ", " + num3 + ", " + num4 + ", " + num5 + ", " + num6 + ")");
        db.close();
    }

    // Lotto Table 데이터 수정
//    public void Update(String name, int age, String Addr) {
//        SQLiteDatabase db = getWritableDatabase();
//        db.execSQL("UPDATE Lotto SET age = " + age + ", ADDR = '" + Addr + "'" + " WHERE NAME = '" + name + "'");
//        db.close();
//    }

    // Lotto Table 데이터 삭제
//    public void Delete(String name) {
//        SQLiteDatabase db = getWritableDatabase();
//        db.execSQL("DELETE Lotto WHERE NAME = '" + name + "'");
//        db.close();
//    }

    // Lotto Table 조회
    public String getResult() {
        // 읽기가 가능하게 DB 열기
        SQLiteDatabase db = getReadableDatabase();
        String result = "";

        // DB에 있는 데이터를 쉽게 처리하기 위해 Cursor를 사용하여 테이블에 있는 모든 데이터 출력
        Cursor cursor = db.rawQuery("SELECT * FROM Lotto ORDER BY numround DESC", null);
        while (cursor.moveToNext()) {
            result += "로또 회차 : " + cursor.getInt(0) + "회"
                    + "  =>  " + cursor.getInt(1)
                    + "  " + cursor.getInt(2)
                    + "  " + cursor.getInt(3)
                    + "  " + cursor.getInt(4)
                    + "  " + cursor.getInt(5)
                    + "  " + cursor.getInt(6)
                    + "\n";
        }

        return result;
    }
}

